# Tic-Tac-Toe-Game
Welcome to the repository for the game Tic-Tac-Toe! This project is a straightforward computer-versus-computer Tic-Tac-Toe game. The objective is to offer users who wish to play the traditional game of Tic-Tac-Toe an enjoyable and engaging experience.

## How to Play
The classic rules of the game of tic tac toe are as follows:

A 3x3 grid is used to play the game.
Each player marks an empty cell with their sign (X or O) in turn.
The winner of the game is the player who correctly arranges three of their marks in a row that is horizontal, vertical, or diagonal.
The game is a draw if the grid is full and no player has three consecutive marks.

## Features
In single-player mode: Compete with a computer opponent.
Randomized computer moves: The machine performs calculated, strategic moves that are not insurmountable.

## Commencing
1. clone the repository
2. Run the game on cmd.
